### Personal information ###
Age:26
Sex:M
Dominant hand:R
Scared of Interviews (1-10):4

### Study pre-requisites ###
Did you drink coffee today? Y
Did you drink coffee within the last hour? N
Did you do any sports today? N
Are you a smoker?N 
Did you smoke within the last hour? N
Do you feel ill today? N

### Additional notes ###
Was set on making an impression and thought arithmetic was very stressful