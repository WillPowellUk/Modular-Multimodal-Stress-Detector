### Personal information ###
Age:28
Sex:M
Dominant hand:R
Scared of Interviews (1-10):2

### Study pre-requisites ###
Did you drink coffee today? Yes
Did you drink coffee within the last hour? No
Did you do any sports today? No
Are you a smoker? No
Did you smoke within the last hour? No
Do you feel ill today? No

### Additional notes ###
Felt a little stressed facing the chairs during baseline recordings. Protocol has moved to facing radiator.