### Personal information ###
Age:34
Sex:M
Dominant hand:R
Scared of Interviews (1-10):5

### Study pre-requisites ###
Did you drink coffee today?Y 
Did you drink coffee within the last hour?N 
Did you do any sports today?N 
Are you a smoker?Y 
Did you smoke within the last hour?N 
Do you feel ill today?N 

### Additional notes ###