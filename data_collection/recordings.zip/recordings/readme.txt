### Personal information ###
Age:
Sex:
Dominant hand:
Scared of Interviews (1-10):

### Study pre-requisites ###
Did you drink coffee today? 
Did you drink coffee within the last hour? 
Did you do any sports today? 
Are you a smoker? 
Did you smoke within the last hour? 
Do you feel ill today? 

### Additional notes ###